#pragma once
#include <juce_audio_processors/juce_audio_processors.h>
#include <juce_dsp/juce_dsp.h>
#include <atomic>
#include <array>
#include <deque>
#include <vector>

#include "audio/Slice.h"
#include "audio/SampleData.h"
#include "audio/SliceManager.h"
#include "audio/VoicePool.h"
#if DYSEKT_STANDALONE
#include "sequencer/SequencerEngine.h"
#include "sequencer/AbletonLink.h"
#endif
#include "audio/LazyChopEngine.h"
#include "audio/SoundFontLoader.h"
#include "audio/SfzPlayer.h"
#include "UndoManager.h"
#include "MidiLearnManager.h"
#include "CrashLogger.h"
#include "params/ParamIds.h"
#include "params/ParamLayout.h"

// Forward-declare to avoid pulling the full signalsmith header into every TU
// that includes PluginProcessor.h.  The stretcher lives only in the .cpp.
namespace signalsmith { namespace stretch {
    template<typename Sample, class RandomEngine> struct SignalsmithStretch;
}}

struct SfzSlicePayload;

//==============================================================================
// ── Spectrum analyser — written from audio thread, read by GlobalEqPanel ──────
// Lock-free double buffer.  Audio thread writes into whichever buffer the UI is
// NOT reading, then atomically flips readIndex.  A torn frame is just a slightly
// stale spectrum — no mutex needed.
class SpectrumAnalyser
{
public:
    static constexpr int fftOrder = 11;            // 2048-point FFT
    static constexpr int fftSize  = 1 << fftOrder; // 2048
    static constexpr int numBins  = fftSize / 2;   // 1024

    SpectrumAnalyser()
        : fft    (fftOrder),
          window (fftSize, juce::dsp::WindowingFunction<float>::hann)
    {
        buffers[0].fill (0.f);
        buffers[1].fill (0.f);
    }

    // Call from processBlock() AFTER the global EQ has processed.
    void pushSamples (const juce::AudioBuffer<float>& buf)
    {
        const int numCh      = buf.getNumChannels();
        const int numSamples = buf.getNumSamples();
        if (numCh == 0 || numSamples == 0) return;

        const float invCh = 1.f / (float) numCh;
        for (int s = 0; s < numSamples; ++s)
        {
            float mono = 0.f;
            for (int ch = 0; ch < numCh; ++ch)
                mono += buf.getReadPointer (ch)[s];
            pushSample (mono * invCh);
        }
    }

    // UI thread: returns the latest completed FFT frame.
    // Values are normalised 0..1  (1.0 = 0 dBFS, 0.0 = –80 dBFS).
    const std::array<float, numBins>& getReadBuffer() const noexcept
    {
        return buffers[readIndex.load (std::memory_order_acquire)];
    }

private:
    void pushSample (float sample)
    {
        fifo[fifoIndex++] = sample;
        if (fifoIndex == fftSize)
        {
            fifoIndex = 0;
            const int writeIdx = 1 - readIndex.load (std::memory_order_relaxed);
            std::copy (fifo.begin(), fifo.end(), fftData.begin());
            window.multiplyWithWindowingTable (fftData.data(), (size_t) fftSize);
            fft.performFrequencyOnlyForwardTransform (fftData.data());
            for (int i = 0; i < numBins; ++i)
            {
                const float mag = fftData[i] / (float) fftSize;
                const float dB  = juce::Decibels::gainToDecibels (mag, -80.f);
                buffers[writeIdx][i] = juce::jmap (dB, -80.f, 0.f, 0.f, 1.f);
            }
            readIndex.store (writeIdx, std::memory_order_release);
        }
    }

    juce::dsp::FFT                      fft;
    juce::dsp::WindowingFunction<float> window;
    std::array<float, fftSize>          fifo     {};
    std::array<float, fftSize>          fftData  {};
    int                                 fifoIndex { 0 };
    std::array<float, numBins>          buffers[2] {};
    std::atomic<int>                    readIndex  { 0 };

    JUCE_DECLARE_NON_COPYABLE (SpectrumAnalyser)
};

//==============================================================================
class DysektProcessor : public juce::AudioProcessor
{
public:
    // =========================================================================
    // Inner types
    // =========================================================================

    // Param field identifiers for CmdSetSliceParam.
    // Values are also used as MidiLearnManager slot indices — do not reorder.
    enum SliceParamField
    {
        FieldBpm = 0,
        FieldPitch,
        FieldAlgorithm,
        FieldAttack,
        FieldDecay,
        FieldSustain,
        FieldRelease,
        FieldMuteGroup,
        FieldStretchEnabled,
        FieldTonality,
        FieldFormant,
        FieldFormantComp,
        FieldGrainMode,
        FieldVolume,
        FieldReleaseTail,
        FieldReverse,
        FieldOutputBus,
        FieldLoop,
        FieldOneShot,
        FieldCentsDetune,
        FieldMidiNote,
        FieldSliceStart,   // 21 - normalised 0-1 -> startSample via MIDI CC
        FieldSliceEnd,     // 22 - normalised 0-1 -> endSample via MIDI CC
        FieldPan,          // 23 - per-slice pan -1..+1
        FieldFilterCutoff, // 24 - per-slice LP filter cutoff Hz
        FieldFilterRes,    // 25 - per-slice LP filter resonance 0..1
        FieldChromaticChannel, // 26 - per-slice chromatic MIDI channel (0=off, 1-16)
        FieldChromaticLegato,  // 27 - per-slice chromatic legato (bool)
        FieldTrimOut = 28,     // 28 - trim-out marker via MIDI CC
        FieldHold   = 29,      // 29 - per-slice AHDSR hold time (seconds)
        FieldZoom   = 30,      // 30 - waveform zoom level
        FieldScroll = 31,      // 31 - waveform scroll position
        FieldGlobalMono = 30,  // 30 - global Poly/Mono switch (bool)
        // SfzPlayer ADSR — slots 32-35
        FieldSfzAttack  = 32,  // 32 - sfizz ampeg_attack  (seconds, 0-30)
        FieldSfzDecay   = 33,  // 33 - sfizz ampeg_decay   (seconds, 0-30)
        FieldSfzSustain = 34,  // 34 - sfizz ampeg_sustain (percent, 0-100)
        FieldSfzRelease = 35,  // 35 - sfizz ampeg_release (seconds, 0-60)
        // SfzPlayer Reverb EFX — slots 36-40
        FieldSfzReverbSize   = 36,  // 36 - reverb room size  (0-100 %)
        FieldSfzReverbDamp   = 37,  // 37 - reverb damping    (0-100 %)
        FieldSfzReverbWidth  = 38,  // 38 - reverb width      (0-100 %)
        FieldSfzReverbMix    = 39,  // 39 - reverb wet/dry    (0-100 %)
        FieldSfzReverbFreeze = 40,  // 40 - reverb freeze     (bool)
        // SfzPlayer master knobs — slots 41-44
        FieldSfzVol       = 41,  // 41 - master volume   (0..2 linear, maps 0-100%)
        FieldSfzTranspose = 42,  // 42 - transpose       (-24..+24 semitones)
        FieldSfzPan       = 43,  // 43 - pan             (-1..+1)
        FieldSfzFineTune  = 44,  // 44 - fine tune       (-100..+100 cents)
        // v24: per-slice EQ
        FieldEqLowGain    = 45,  // dB  -18..+18
        FieldEqMidGain    = 46,  // dB  -18..+18
        FieldEqMidFreq    = 47,  // Hz  200..8000
        FieldEqMidQ       = 48,  // Q   0.5..4.0
        FieldEqHighGain   = 49,  // dB  -18..+18
    };

    // ── Command types ────────────────────────────────────────────────────────
    enum CommandType
    {
        CmdNone = 0,
        CmdLoadFile,
        CmdCreateSlice,
        CmdDeleteSlice,
        CmdLazyChopStart,
        CmdLazyChopStop,
        CmdStretch,
        CmdToggleLock,
        CmdSetSliceParam,
        CmdSetSliceBounds,
        CmdSplitSlice,
        CmdTransientChop,
        CmdEqualChop,
        CmdRelinkFile,
        CmdFileLoadCompleted,
        CmdFileLoadFailed,
        CmdUndo,
        CmdRedo,
        CmdBeginGesture,
        CmdPanic,
        CmdSelectSlice,
        CmdSetRootNote,
        CmdApplyTrim,
        CmdSetSliceLockAll,  // intParam1 = slice index, floatParam1 = 1.0 lock all / 0.0 unlock all
        CmdSetSliceColour,   // intParam1 = slice index, intParam2 = ARGB colour
        CmdSetSliceName,     // intParam1 = slice index, stringParam = new name (empty = clear)
    };

    // ── Load kind ────────────────────────────────────────────────────────────
    enum LoadKind { LoadKindReplace = 0, LoadKindRelink = 1 };

    // ── Trim preference ───────────────────────────────────────────────────────
    enum TrimPreference { TrimPrefAsk = 0, TrimPrefAlways = 1, TrimPrefNever = 2 };

    // ── Sample availability state ────────────────────────────────────────────
    enum SampleAvailabilityState
    {
        SampleStateEmpty                 = 0,
        SampleStateLoaded                = 1,
        SampleStateMissingAwaitingRelink = 2,
    };

    // ── Command ──────────────────���───────────────────────────────────────────
    struct Command
    {
        CommandType type        { CmdNone };
        int         intParam1   { 0 };
        int         intParam2   { 0 };
        float       floatParam1 { 0.0f };
        juce::File  fileParam;
        juce::String stringParam;   // used by CmdSetSliceName
        static constexpr int kMaxPositions = SliceManager::kMaxSlices + 2;
        std::array<int, kMaxPositions> positions {};
        int numPositions { 0 };
        bool isCommit { false };    // CmdSetSliceBounds: true = mouseUp final commit, triggers crush inheritance
    };

    // ── UI snapshot (double-buffered, written on audio thread) ───────────────
    struct UiSliceSnapshot
    {
        std::array<Slice, SliceManager::kMaxSlices> slices;
        int          numSlices          { 0 };
        int          selectedSlice      { -1 };
        int          rootNote           { 36 };
        bool         sampleLoaded       { false };
        bool         sampleMissing      { false };
        int          sampleNumFrames    { 0 };
        juce::String sampleFileName;
        bool         isDefaultSample   { false };
        bool         midiSelectsSlice   { false };
    };

    // ── Oscilloscope ring buffer size ─────────────────��───────────────────────
    static constexpr int kOscRingBufferSize = 4096;  // must be power of 2

    // =========================================================================
    // Constructor / Destructor
    // =========================================================================
    DysektProcessor();
    ~DysektProcessor() override;

    // =========================================================================
    // AudioProcessor overrides
    // =========================================================================
    void prepareToPlay (double sampleRate, int samplesPerBlock) override;
    void releaseResources() override;
    bool isBusesLayoutSupported (const BusesLayout& layouts) const override;
    void processBlock (juce::AudioBuffer<float>&, juce::MidiBuffer&) override;

    juce::AudioProcessorEditor* createEditor() override;
    bool hasEditor() const override              { return true; }

    const juce::String getName() const override  { return "DYSEKT"; }
    bool acceptsMidi()  const override           { return true; }
    bool producesMidi() const override           { return false; }
    bool isMidiEffect() const override           { return false; }
    double getTailLengthSeconds() const override { return 0.0; }

    int  getNumPrograms()    override { return 1; }
    int  getCurrentProgram() override { return 0; }
    void setCurrentProgram (int) override {}
    const juce::String getProgramName (int) override { return "Default"; }
    void changeProgramName (int, const juce::String&) override {}

    void getStateInformation (juce::MemoryBlock& destData) override;
    void setStateInformation (const void* data, int sizeInBytes) override;

    // =========================================================================
    // Public API
    // =========================================================================
    void pushCommand (Command cmd);

    /** Controls where incoming live MIDI is routed.
     *
     *  Slicer    — all channels (except sf2Ch) go to the slice engine.
     *              sfzPlayer receives mask = 0 (no live input).
     *  SfPlayer  — slicer is bypassed entirely; sfzPlayer receives
     *              mask = all assigned SF-track channels.
     *  Sequencer — sequencer drives SF output; sfzPlayer live mask is
     *              governed by setSelectedSfLiveChannels(); slicer is bypassed.
     */
    enum class MidiRouteMode { Slicer, SfPlayer, Sequencer };
    void setMidiRouteMode (MidiRouteMode mode);

    void loadFileAsync      (const juce::File& file);
    void loadDefaultSampleIfNeeded();   // loads Empty.wav on first launch

    // ADSR param pointers — read by SliceWaveformLcd for envelope display
    std::atomic<float>* attackParam       { nullptr };
    std::atomic<float>* decayParam        { nullptr };
    std::atomic<float>* sustainParam      { nullptr };
    std::atomic<float>* releaseParam      { nullptr };
    std::atomic<float>* holdParam         { nullptr };
    void loadSoundFontAsync (const juce::File& file);
    void relinkFileAsync    (const juce::File& file);
    void applyTrimToCurrentSample (int trimStart, int trimEnd);

    /** Read-only access to the latest published UI snapshot (UI thread only). */
    const UiSliceSnapshot& getUiSliceSnapshot() const noexcept
    {
        return uiSliceSnapshots[(size_t) uiSliceSnapshotIndex.load (std::memory_order_acquire)];
    }

    int getUiSliceSnapshotVersion() const noexcept
    {
        return (int) uiSnapshotVersion.load (std::memory_order_acquire);
    }

    void publishUiSliceSnapshot();

    /** Returns the peak amplitude (0..1) at a given sample position in the
     *  loaded audio buffer.  Used by SliceWaveformLcd to render the mini waveform.
     *  Safe to call from the UI (message) thread. */
    float getWaveformPeakAt (int samplePosition) const noexcept
    {
        if (! sampleData.isLoaded()) return 0.0f;
        const auto& buf = sampleData.getBuffer();
        const int n = buf.getNumSamples();
        if (samplePosition < 0 || samplePosition >= n) return 0.0f;
        float peak = 0.0f;
        for (int ch = 0; ch < buf.getNumChannels(); ++ch)
            peak = std::max (peak, std::abs (buf.getSample (ch, samplePosition)));
        return peak;
    }

    // =========================================================================
    // Public subsystem members (accessed directly by UI)
    // =========================================================================
    juce::AudioProcessorValueTreeState apvts;
    SliceManager     sliceManager;
    VoicePool        voicePool;
#if DYSEKT_STANDALONE
    SequencerEngine  sequencer;
    AbletonLink      abletonLink;
#endif
    LazyChopEngine   lazyChop;
    SampleData       sampleData;
    MidiLearnManager midiLearn;

    // ── SFZ live player ───────────────────────────────────────────────────────
    SfzPlayer sfzPlayer;

    // ── Spectrum analyser (post-EQ FFT data, read by GlobalEqPanel timer) ────
    SpectrumAnalyser spectrumAnalyser;

    // =========================================================================
    // UI-readable state atomics
    // =========================================================================
    std::atomic<float> zoom   { 1.0f };
    std::atomic<float> scroll { 0.0f };
    std::atomic<float> dawBpm { 120.0f };

    std::atomic<bool> midiSelectsSlice   { false };
    std::atomic<int>  midiFollowTriggeredSlice { -1 }; // last MIDI-triggered slice idx for waveform viewport follow

    // Per-slice peak meters (0..1, decaying, written from audio thread)
    static constexpr int kMaxMeterSlices = 128;
    std::array<std::atomic<float>, kMaxMeterSlices> slicePeakL {};
    std::array<std::atomic<float>, kMaxMeterSlices> slicePeakR {};
    // Master output peak meters (0..1, decaying, written in audio thread, read by UI)
    std::atomic<float> masterPeakL {0.0f}, masterPeakR {0.0f};
    // Peak meters written by processBlock, read by SfzModulePanel timer
    std::atomic<float> sfzPeakL { 0.0f };
    std::atomic<float> sfzPeakR { 0.0f };
    // Live drag bounds (UI -> audio thread, bypasses FIFO for low latency)
    std::atomic<int> liveDragBoundsStart { 0 };
    std::atomic<int> liveDragBoundsEnd   { 0 };
    std::atomic<int> liveDragSliceIdx    { -1 };
    // --- Optimistic marker commit notification for UI (set on knob/CC commit, cleared by UI) ---
    std::atomic<int> pendingUiOptimisticIdx { -1 };
    std::atomic<int> pendingUiOptimisticSample { -1 };
    std::atomic<int>   paramsSyncedForSlice   { -1 };  // slice index that sliceStartParam/sliceEndParam currently describe
    std::atomic<float> sliceStartPublished    { -1.0f }; // value written when syncing, used to detect real CC moves
    // Pre-pickup ghost position for FieldSliceStart absolute CC.
    // Written by the audio thread (processMidi) each time an absolute CC for
    // FieldSliceStart arrives while ccPickedUp is false. Read by the UI thread
    // (drawMarkerSliderCell) to draw a ghost cursor showing where the physical
    // knob/fader is vs. where the actual marker is. -1.0f = not active.
    std::atomic<float> markerCcGhostNorm { -1.0f };

    // Relative encoder directional indicator for Marker slider.
    // markerRelDir: -1 = CCW, 0 = idle, +1 = CW
    // markerRelLastMs: timestamp of last encoder tick for fade-out
    std::atomic<int>  markerRelDir    { 0 };
    std::atomic<int>  markerRelLastMs { 0 };

    // Fine window state for post-pickup absolute CC marker control.
    // After pickup, the CC maps to a narrow window (kMarkerFineWindowNorm * totalSamples)
    // centred on the marker position at the moment of pickup, giving ~7x finer resolution.
    // Indexed by slice. Audio-thread only — no atomics needed.
    static constexpr float kMarkerFineWindowNorm = 0.20f; // full knob sweep = 20% of sample
    float markerFinePickupCcNorm   [128] {};   // CC norm (0-1) at pickup moment, -1 = not set
    float markerFinePickupMarkerNorm[128] {};   // marker norm at pickup moment
    // UI: expose fine window for ghost bar drawing (UI thread reads)
    std::atomic<float> markerFineWindowLo { -1.0f }; // low edge norm, -1 = inactive
    std::atomic<float> markerFineWindowHi { -1.0f }; // high edge norm
    // User toggle: when true the post-pickup fine window is active;
    // when false the CC maps the full sample range directly (normal mode).
    std::atomic<bool>  markerFineMode     { false };

    // ── Per-slice CC state ───────────────────────────────────────────────────
    // Each slice independently tracks pickup and smoother state for every
    // MIDI learn slot.  Switching slices never requires pickup re-acquisition
    // for a CC that has already been used on that slice — eliminating the
    // root cause of the cross-slice jump problem.
    //
    // Memory: 128 slices × 30 slots × (1 bool + 1 bool + ~32B smoother) ≈ 128 KB
    // Audio-thread write/read only.
    static constexpr int kMaxCCSlices = 128; // matches SliceManager::kMaxSlices

    // [sliceIdx][fieldId]
    std::array<std::array<bool, kMidiLearnNumSlots>, kMaxCCSlices> ccPickedUp {};
    std::array<std::array<bool, kMidiLearnNumSlots>, kMaxCCSlices> ccSmootherActive {};
    std::array<std::array<juce::SmoothedValue<float, juce::ValueSmoothingTypes::Linear>,
               kMidiLearnNumSlots>, kMaxCCSlices> ccSmoothers;

    // Commit-on-idle for FieldSliceStart CC — write live drag atomics during
    // movement, commit to SliceManager only after kIdleBlocks of silence.
    static constexpr int kMarkerIdleBlocks = 4;  // ~80ms at 512/44100
    int  markerIdleCounter  = 0;    // counts blocks since last CC message
    bool markerPending       = false; // true while a commit is outstanding
    int  markerPendingSlice  = -1;   // which slice the pending commit is for
    int  markerSmootherSlice  = -1;  // slice active when absolute-CC smoother was seeded
    int  lastProcessedSlice   = -1;  // detects direct selectedSlice.store() changes between blocks
    int  ccLastDispatchedSel  = -1;  // intra-buffer slice-switch guard (see processMidi)
    std::atomic<float> sliceEndPublished      { -1.0f };

    // Shift-preview request (-2 = idle, -1 = stop, >= 0 = start at position)
    std::atomic<int> shiftPreviewRequest { -2 };

    // ── UI pad-click MIDI injection ───────────────────────────────────────────
    // Written by the UI thread (PadGridView::mouseDown/Up), consumed in processBlock.
    // -1 = nothing pending.
    std::atomic<int> uiNoteOnRequest  { -1 };
    std::atomic<int> uiNoteOffRequest { -1 };

    // SF2 / SFZ keyboard UI note injection — routed on the sfz channel (ch16)
    // so processMidi() skips them and only sfzPlayer receives them.
    std::atomic<int> sfzUiNoteOnRequest  { -1 };
    std::atomic<int> sfzUiNoteOffRequest { -1 };

    // 128-bit active-note bitmask for the SF2/SFZ player (updated on audio thread,
    // read on UI thread for KeysPanel highlighting — display-only, torn reads OK).
    // Bit N of word 0 = note N (0-63); bit N of word 1 = note N+64 (64-127).
    std::atomic<uint64_t> sfzActiveNotes[2] {}; // [0]=notes 0-63, [1]=notes 64-127

    // Trim region markers (stored in samples)
    std::atomic<int>  trimRegionStart  { 0 };
    std::atomic<int>  trimRegionEnd    { 0 };
    std::atomic<bool> trimModeActive   { false };  // set by editor; CC routes to trim when true
    std::atomic<int>  midiRouteMode    { 0 };       // 0=Slicer, 1=SfPlayer, 2=Sequencer
    std::atomic<int> trimInSample    { 0 };
    std::atomic<int> trimOutSample   { 0 };

    // Trim dialog preference (persisted)
    std::atomic<int> trimPreference  { (int) TrimPrefAsk };

    // Oscilloscope ring buffer (audio thread writes, UI reads)
    std::array<float, kOscRingBufferSize> oscRingBuffer {};
    std::atomic<int> oscRingWriteHead { 0 };

    // Sample availability (see SampleAvailabilityState enum)
    std::atomic<int>  sampleAvailability { (int) SampleStateEmpty };
    std::atomic<bool> sampleMissing      { false };
    juce::String      missingFilePath;

    /** Set by setStateInformation when restoring an SF2 preset index.
     *  The editor polls this on its timer and applies it once the preset
     *  list becomes available, then resets it to -1. */
    std::atomic<int> pendingSfzPresetIndex { -1 };

    // Peak metering (written in processBlock, read by UI)

private:
    // =========================================================================
    // Private types
    // =========================================================================
    struct FailedLoadResult
    {
        int        token { 0 };
        LoadKind   kind  { LoadKindReplace };
        juce::File file;
    };

    // =========================================================================
    // Private helpers
    // =========================================================================
    void requestSampleLoad (const juce::File& file, LoadKind kind);
    void clearVoicesBeforeSampleSwap();
    void clampSlicesToSampleBounds();
    void handleCommand (const Command& cmd);
    void drainCommands();
    void drainOverflowCommands (bool& handledAny);
    void drainCoalescedCommands (bool& handledAny);
    bool enqueueOverflowCommand (Command cmd);
    bool enqueueCoalescedCommand (const Command& cmd);
    void processMidi (const juce::MidiBuffer& midi);

    UndoManager::Snapshot makeSnapshot();
    void captureSnapshot();
    void restoreSnapshot (const UndoManager::Snapshot& snap);

    static float sanitiseSample (float s) noexcept
    {
        return (std::isfinite (s) && s >= -8.0f && s <= 8.0f) ? s : 0.0f;
    }

    // =========================================================================
    // Command FIFO
    // =========================================================================
    static constexpr int kCommandFifoSize  = 256;
    static constexpr int kOverflowFifoSize = 32;

    juce::AbstractFifo commandFifo { kCommandFifoSize };
    std::array<Command, kCommandFifoSize> commandBuffer;

    std::array<Command, kOverflowFifoSize> overflowCommandBuffer {};
    std::atomic<int> overflowWriteIndex { 0 };
    std::atomic<int> overflowReadIndex  { 0 };

    // Coalescing slots for high-frequency drag commands
    std::atomic<bool>  pendingSetSliceParam         { false };
    std::atomic<int>   pendingSetSliceParamField    { 0 };
    std::atomic<float> pendingSetSliceParamValue    { 0.0f };
    std::atomic<int>   pendingSetSliceParamSkipLock { 0 };   // preserves intParam2 through coalesce

    std::atomic<bool> pendingSetSliceBounds      { false };
    std::atomic<int>  pendingSetSliceBoundsIdx   { -1 };
    std::atomic<int>  pendingSetSliceBoundsStart { 0 };
    std::atomic<int>  pendingSetSliceBoundsEnd   { 0 };

    // Diagnostics
    std::atomic<int> droppedCommandCount         { 0 };
    std::atomic<int> droppedCommandTotal         { 0 };
    std::atomic<int> droppedCriticalCommandTotal { 0 };

    // =========================================================================
    // UI snapshot double-buffer
    // =========================================================================
    std::array<UiSliceSnapshot, 2> uiSliceSnapshots;
    std::atomic<int>      uiSliceSnapshotIndex { 0 };
    std::atomic<uint32_t> uiSnapshotVersion    { 0 };
    std::atomic<bool>     uiSnapshotDirty      { false };

    // =========================================================================
    // Undo / redo
    // =========================================================================
    UndoManager undoMgr;
    bool gestureSnapshotCaptured    { false };
    int  blocksSinceGestureActivity { 0 };

    // =========================================================================
    // Sample loading
    // =========================================================================
    juce::ThreadPool fileLoadPool { 1 };
    bool             defaultSampleScheduled { false }; // true once default or saved sample is queued
    std::atomic<int>  nextLoadToken  { 0 };
    std::atomic<int>  latestLoadToken{ 0 };
    std::atomic<int>  latestLoadKind { (int) LoadKindReplace };
    std::atomic<SampleData::DecodedSample*> completedLoadData   { nullptr };
    std::atomic<FailedLoadResult*>          completedLoadFailure { nullptr };
    std::atomic<SfzSlicePayload*>           pendingSfzSlices     { nullptr };


    // =========================================================================
    // APVTS parameter pointers (assigned in constructor, constant thereafter)
    // =========================================================================
    std::atomic<float>* masterVolParam    { nullptr };
    std::atomic<float>* bpmParam          { nullptr };
    std::atomic<float>* pitchParam        { nullptr };
    std::atomic<float>* algoParam         { nullptr };

    std::atomic<float>* muteGroupParam    { nullptr };
    std::atomic<float>* monoParam         { nullptr };
    std::atomic<float>* stretchParam      { nullptr };
    std::atomic<float>* tonalityParam     { nullptr };
    std::atomic<float>* formantParam      { nullptr };
    std::atomic<float>* formantCompParam  { nullptr };
    std::atomic<float>* grainModeParam    { nullptr };
    std::atomic<float>* releaseTailParam  { nullptr };
    std::atomic<float>* reverseParam      { nullptr };
    std::atomic<float>* loopParam         { nullptr };
    std::atomic<float>* oneShotParam      { nullptr };
    std::atomic<float>* maxVoicesParam    { nullptr };
    std::atomic<float>* centsDetuneParam  { nullptr };
    std::atomic<float>* panParam          { nullptr };
    std::atomic<float>* filterCutoffParam { nullptr };
    std::atomic<float>* filterResParam    { nullptr };
    std::atomic<float>* sliceStartParam   { nullptr };
    std::atomic<float>* sliceEndParam     { nullptr };
    std::atomic<float>* masterPitchParam  { nullptr };  // v25: master audio-domain pitch shift

    // =========================================================================
    // Playback state
    // =========================================================================
    double currentSampleRate { 44100.0 };
    bool   heldNotes[128]    {};

    // ── Global post-mix EQ (juce::dsp, runs after voice mix, before master volume) ──
    juce::dsp::ProcessorChain<
        juce::dsp::IIR::Filter<float>,   // band 0: low shelf  (~80 Hz)
        juce::dsp::IIR::Filter<float>,   // band 1: low-mid peak (draggable 100–1000 Hz)
        juce::dsp::IIR::Filter<float>,   // band 2: mid peak   (draggable 500–5000 Hz)
        juce::dsp::IIR::Filter<float>,   // band 3: high-mid peak (draggable 1–10 kHz)
        juce::dsp::IIR::Filter<float>    // band 4: high shelf (~12 kHz)
    > globalEq;
    bool globalEqNeedsUpdate = true;

    // ── v25: master audio-domain pitch shift (post-EQ, pre-output) ───────────
    // Uses signalsmith-stretch in pitch-only mode (stretch ratio = 1.0).
    // Allocated in prepareToPlay; nullptr until then.
    std::unique_ptr<signalsmith::stretch::SignalsmithStretch<float, void>> masterPitchShifter;
    float  masterPitchSemitones = 0.0f;   // last applied value — avoid reinit on no change
    // Per-channel scratch buffers resized in prepareToPlay
    std::vector<float> masterPitchScratchL;
    std::vector<float> masterPitchScratchR;

    friend class SoundFontLoader;

    // ── Crash logger ──────────────────────────────────────────────────────────
    // Declared last so it is constructed first and destroyed last,
    // ensuring the log captures the full object lifetime.
    CrashLogger crashLogger;

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR (DysektProcessor)
};
